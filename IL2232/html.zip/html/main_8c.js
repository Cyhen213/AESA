var main_8c =
[
    [ "No2Channel", "main_8c.html#ab6c78568e5ac4cc741c5ee6dcf1a381e", null ],
    [ "Nob", "main_8c.html#a5e8ee6e8f7371ec2709dbb5335c12a2a", null ],
    [ "NoB", "main_8c.html#a2979ea28bbec7e71bd46710f81d594dc", null ],
    [ "NoChannel", "main_8c.html#ad1470103e23232bfa0f32b9253b1f4ce", null ],
    [ "NoFFT", "main_8c.html#a866e42b41b8526d9dd1493d278bb9f1d", null ],
    [ "main", "main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ]
];