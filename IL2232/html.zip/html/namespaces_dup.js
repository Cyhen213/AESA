var namespaces_dup =
[
    [ "data_csv", "namespacedata__csv.html", [
      [ "df", "namespacedata__csv.html#a1d25b980de178d7653c612be57ccd397", null ],
      [ "False", "namespacedata__csv.html#ad24acbdd5c65ae2c1c07ceced8a7652d", null ],
      [ "header", "namespacedata__csv.html#af5bfd37cb98ef1da4c9e3d37eff1dd01", null ],
      [ "index", "namespacedata__csv.html#ad0d5ba76133fc316af6ecbc406dce348", null ]
    ] ]
];