var searchData=
[
  ['logbase2_0',['logBase2',['../skeletons_8c.html#ab5134cf54d23c5383ea3fb55818bc2a9',1,'logBase2(double input):&#160;skeletons.c'],['../skeletons_8h.html#ab5134cf54d23c5383ea3fb55818bc2a9',1,'logBase2(double input):&#160;skeletons.c']]],
  ['logbase2_5fdiv4_1',['logBase2_div4',['../skeletons_8c.html#a52b119c2ef2bef6674817557d19ac0bb',1,'logBase2_div4(double input):&#160;skeletons.c'],['../skeletons_8h.html#a52b119c2ef2bef6674817557d19ac0bb',1,'logBase2_div4(double input):&#160;skeletons.c']]]
];
