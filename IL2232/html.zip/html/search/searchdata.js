var indexSectionsWithContent =
{
  0: "acdfglmnorst",
  1: "ams",
  2: "acdfglmnorst",
  3: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros"
};

