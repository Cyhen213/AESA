var searchData=
[
  ['add_0',['add',['../skeletons_8c.html#a95319c31b1b32e219d858c43c9eea18d',1,'add(double input1, double input2):&#160;skeletons.c'],['../skeletons_8h.html#a95319c31b1b32e219d858c43c9eea18d',1,'add(double input1, double input2):&#160;skeletons.c']]],
  ['add_5fone_1',['add_one',['../skeletons_8h.html#a52ffef041e9a03c1e348ce3d8292cced',1,'skeletons.h']]],
  ['addv_2',['addV',['../skeletons_8c.html#a6bc8e3f13b0fb9736eca53f83363bfaf',1,'addV(double *inputVector1, double *inputVector2, int len_array):&#160;skeletons.c'],['../skeletons_8h.html#a6bc8e3f13b0fb9736eca53f83363bfaf',1,'addV(double *inputVector1, double *inputVector2, int len_array):&#160;skeletons.c']]],
  ['aesa_2ec_3',['AESA.c',['../_a_e_s_a_8c.html',1,'']]],
  ['aesa_2eh_4',['AESA.h',['../_a_e_s_a_8h.html',1,'']]],
  ['allocate_5fcube_5',['allocate_cube',['../skeletons_8c.html#a2d5129e20dc1b785a7fc17fb56e184a5',1,'allocate_cube(int d1, int d2, int d3):&#160;skeletons.c'],['../skeletons_8h.html#a2d5129e20dc1b785a7fc17fb56e184a5',1,'allocate_cube(int d1, int d2, int d3):&#160;skeletons.c']]],
  ['allocate_5fcube_5ffrom_5fcube_6',['allocate_cube_from_cube',['../skeletons_8c.html#ae2d0a4c4b2db37865ed31eee502ccd5e',1,'allocate_cube_from_cube(int d1, int d2, int d3, double cube[d1][d2][d3]):&#160;skeletons.c'],['../skeletons_8h.html#ae2d0a4c4b2db37865ed31eee502ccd5e',1,'allocate_cube_from_cube(int d1, int d2, int d3, double cube[d1][d2][d3]):&#160;skeletons.c']]],
  ['allocate_5fmat_7',['allocate_mat',['../skeletons_8c.html#af98b87866cc7ff49f1783594468c1c1e',1,'allocate_mat(int d1, int d2):&#160;skeletons.c'],['../skeletons_8h.html#af98b87866cc7ff49f1783594468c1c1e',1,'allocate_mat(int d1, int d2):&#160;skeletons.c']]],
  ['arithmean_8',['arithmean',['../_a_e_s_a_8c.html#a1c6234ea19a262bd3677b30a5e05f417',1,'arithmean(int d1, int d2, double **input_matrix):&#160;AESA.c'],['../_a_e_s_a_8h.html#a1c6234ea19a262bd3677b30a5e05f417',1,'arithmean(int d1, int d2, double **input_matrix):&#160;AESA.c']]]
];
