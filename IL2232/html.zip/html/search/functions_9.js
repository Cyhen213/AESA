var searchData=
[
  ['print_5farray_0',['print_array',['../skeletons_8c.html#a3b2179d5fab3b22c51102d8f4babfc99',1,'print_array(double *array, int length):&#160;skeletons.c'],['../skeletons_8h.html#a3b2179d5fab3b22c51102d8f4babfc99',1,'print_array(double *array, int length):&#160;skeletons.c']]],
  ['print_5fcube_1',['print_cube',['../skeletons_8c.html#af73ef8f60ae03339dd8abe35d0f9076b',1,'print_cube(int d1, int d2, int d3, double ***cube):&#160;skeletons.c'],['../skeletons_8h.html#af73ef8f60ae03339dd8abe35d0f9076b',1,'print_cube(int d1, int d2, int d3, double ***cube):&#160;skeletons.c']]],
  ['print_5fmatrix_2',['print_matrix',['../skeletons_8c.html#a31e384448a0ec8e6ed91a352ba2e1eab',1,'print_matrix(int d1, int d2, double **matrix):&#160;skeletons.c'],['../skeletons_8h.html#a31e384448a0ec8e6ed91a352ba2e1eab',1,'print_matrix(int d1, int d2, double **matrix):&#160;skeletons.c']]]
];
