var searchData=
[
  ['reduce1d_0',['reduce1d',['../skeletons_8c.html#a188fc74e692648cf193f14e24db76023',1,'reduce1d(double(*operation)(double, double), int array_len, double *input_array):&#160;skeletons.c'],['../skeletons_8h.html#a188fc74e692648cf193f14e24db76023',1,'reduce1d(double(*operation)(double, double), int array_len, double *input_array):&#160;skeletons.c']]],
  ['reducev2d_1',['reduceV2d',['../skeletons_8c.html#a39aa34d3d11edd6336b594fb68b03491',1,'reduceV2d(int d1, int d2, double *(*operation)(double *, double *, int d2), double **input_matrix):&#160;skeletons.c'],['../skeletons_8h.html#a39aa34d3d11edd6336b594fb68b03491',1,'reduceV2d(int d1, int d2, double *(*operation)(double *, double *, int d2), double **input_matrix):&#160;skeletons.c']]],
  ['reducev3d_2',['reduceV3d',['../skeletons_8c.html#a75a2ebb80fb9ed23ba3b5d3b62d3cde9',1,'skeletons.c']]]
];
