var searchData=
[
  ['skeletons_2ec_0',['skeletons.c',['../skeletons_8c.html',1,'']]],
  ['skeletons_2eh_1',['skeletons.h',['../skeletons_8h.html',1,'']]],
  ['stencil2d_2',['stencil2d',['../skeletons_8c.html#a6d7a783caa561de89131638317f93527',1,'stencil2d(int in_d1, int in_d2, double **a, int stencil_length):&#160;skeletons.c'],['../skeletons_8h.html#a6d7a783caa561de89131638317f93527',1,'stencil2d(int in_d1, int in_d2, double **a, int stencil_length):&#160;skeletons.c']]]
];
