var searchData=
[
  ['header_0',['header',['../namespacedata__csv.html#af5bfd37cb98ef1da4c9e3d37eff1dd01',1,'data_csv']]]
];
