var searchData=
[
  ['div_5fn_0',['div_N',['../skeletons_8c.html#a32be92e37fb1c266bed6f54e8e02db87',1,'div_N(double input):&#160;skeletons.c'],['../skeletons_8h.html#a32be92e37fb1c266bed6f54e8e02db87',1,'div_N(double input):&#160;skeletons.c']]],
  ['drop1d_1',['drop1d',['../skeletons_8c.html#a43e3a26423fd49af26160b7832139828',1,'drop1d(double *input_array, int array_len, int drop_n):&#160;skeletons.c'],['../skeletons_8h.html#a43e3a26423fd49af26160b7832139828',1,'drop1d(double *input_array, int array_len, int drop_n):&#160;skeletons.c']]],
  ['drop2d_2',['drop2d',['../skeletons_8c.html#aa6c741f143c6642f5abb7a2376adb223',1,'drop2d(int d1, int d2, double **input_matrix, int drop_n):&#160;skeletons.c'],['../skeletons_8h.html#aa6c741f143c6642f5abb7a2376adb223',1,'drop2d(int d1, int d2, double **input_matrix, int drop_n):&#160;skeletons.c']]],
  ['drop3d_3',['drop3d',['../skeletons_8c.html#a9ada636e57bdecb9493132d5212c72ea',1,'drop3d(int d1, int d2, int d3, double ***input_cube, int drop_n):&#160;skeletons.c'],['../skeletons_8h.html#a9ada636e57bdecb9493132d5212c72ea',1,'drop3d(int d1, int d2, int d3, double ***input_cube, int drop_n):&#160;skeletons.c']]]
];
