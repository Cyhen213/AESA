var searchData=
[
  ['geomean_0',['geomean',['../_a_e_s_a_8c.html#a983b117e95c7a06b5c2d515e1551f7c4',1,'geomean(int d1, int d2, double **input_matrix):&#160;AESA.c'],['../_a_e_s_a_8h.html#a983b117e95c7a06b5c2d515e1551f7c4',1,'geomean(int d1, int d2, double **input_matrix):&#160;AESA.c']]],
  ['group2d_1',['group2d',['../skeletons_8c.html#a5267b76290fb044313469e26724dbe39',1,'group2d(int d1, int d2, double **input_matrix, int num):&#160;skeletons.c'],['../skeletons_8h.html#a5267b76290fb044313469e26724dbe39',1,'group2d(int d1, int d2, double **input_matrix, int num):&#160;skeletons.c']]]
];
