var searchData=
[
  ['false_0',['False',['../namespacedata__csv.html#ad24acbdd5c65ae2c1c07ceced8a7652d',1,'data_csv']]]
];
