var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['md_1',['md',['../_a_e_s_a_8c.html#a24dad1ecd15a1ee372d09659b4aed175',1,'md(int d1, int d2, double **input_matrix):&#160;AESA.c'],['../_a_e_s_a_8h.html#a24dad1ecd15a1ee372d09659b4aed175',1,'md(int d1, int d2, double **input_matrix):&#160;AESA.c']]],
  ['minimum_2',['minimum',['../skeletons_8c.html#a7525391d9e008451af2cc64b100c1e73',1,'minimum(double num1, double num2):&#160;skeletons.c'],['../skeletons_8h.html#a7525391d9e008451af2cc64b100c1e73',1,'minimum(double num1, double num2):&#160;skeletons.c']]],
  ['minimumvec_3',['minimumVec',['../skeletons_8c.html#a5d231b385a277898f4fd2d70e16cae48',1,'minimumVec(double *inputV1, double *inputV2, int d2):&#160;skeletons.c'],['../skeletons_8h.html#a5d231b385a277898f4fd2d70e16cae48',1,'minimumVec(double *inputV1, double *inputV2, int d2):&#160;skeletons.c']]]
];
