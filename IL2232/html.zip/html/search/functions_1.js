var searchData=
[
  ['concate1d_0',['concate1d',['../skeletons_8c.html#ab9a5ad9e54cfe5340fb5133423c068ec',1,'concate1d(double *array1, double *array2, int array_len):&#160;skeletons.c'],['../skeletons_8h.html#a330c6fa7cac1362b5d89a06757fd52ad',1,'concate1d(double *array1, double *array2, int array_len):&#160;skeletons.c']]],
  ['concate2d_5fmat_1',['concate2d_mat',['../skeletons_8c.html#a49a72359a1c7d93c03e564b5317a60fc',1,'concate2d_mat(int d1_mat1, int d1_mat2, int d2, double **input_matrix1, double **input_matrix2):&#160;skeletons.c'],['../skeletons_8h.html#a49a72359a1c7d93c03e564b5317a60fc',1,'concate2d_mat(int d1_mat1, int d1_mat2, int d2, double **input_matrix1, double **input_matrix2):&#160;skeletons.c']]],
  ['concate3d_5fcube_2',['concate3d_cube',['../skeletons_8c.html#a1154872cc980b3daaf2559d23ea4943e',1,'concate3d_cube(int d1, int d2, int d3, double ***array1, double ***array2):&#160;skeletons.c'],['../skeletons_8h.html#a1154872cc980b3daaf2559d23ea4943e',1,'concate3d_cube(int d1, int d2, int d3, double ***array1, double ***array2):&#160;skeletons.c']]]
];
