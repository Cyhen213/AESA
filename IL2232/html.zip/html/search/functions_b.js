var searchData=
[
  ['take1d_0',['take1d',['../skeletons_8c.html#a736ebfbd19868268ed03492363a17ab1',1,'take1d(double *input_array, int take_n):&#160;skeletons.c'],['../skeletons_8h.html#a736ebfbd19868268ed03492363a17ab1',1,'take1d(double *input_array, int take_n):&#160;skeletons.c']]],
  ['take3d_1',['take3d',['../skeletons_8c.html#a724ade1b42e9f60153ec030013ec130c',1,'take3d(int d1, int d2, int d3, double ***input_cube, int take_n):&#160;skeletons.c'],['../skeletons_8h.html#a724ade1b42e9f60153ec030013ec130c',1,'take3d(int d1, int d2, int d3, double ***input_cube, int take_n):&#160;skeletons.c']]]
];
